export {
  orders as ordersTable,
  orderItems as orderItemsTable,
} from "../db/schema.js";
