export { addresses as addressesTable } from "../db/schema.js";
