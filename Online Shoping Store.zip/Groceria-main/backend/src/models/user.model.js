export { users as usersTable } from "../db/schema.js";
