export { products as productsTable } from "../db/schema.js";
