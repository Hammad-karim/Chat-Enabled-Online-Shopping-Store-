export const DB_NAME = "greencart";
